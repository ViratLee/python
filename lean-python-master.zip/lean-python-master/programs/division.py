from __future__ import print_function
print('Input two numbers. the first will be divided by the second')

afirst = raw_input('first number:')
first=float(afirst)
asecond = raw_input('second number:')
second = float(asecond)

quotient = first / second
print('Quotient first/second = ',quotient)
