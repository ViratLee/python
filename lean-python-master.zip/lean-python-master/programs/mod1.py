from __future__ import print_function

def hello():
    print('hello')

writtenby='Paul'
print(writtenby)

class greeting():
    def morning(self):
        print('Good Morning!')
    def evening(self):
        print('Good Evening!')