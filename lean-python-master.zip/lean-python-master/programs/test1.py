import mod1 as m1

m1.hello()
print 'written by', m1.writtenby

greet = m1.greeting()
greet.morning()
greet.evening()